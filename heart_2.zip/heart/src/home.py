import streamlit as st
import io
def write():
    st.write("hello world")